package com.mycompany.cacaofarmmanager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
