import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'mode_selector_widget.dart' show ModeSelectorWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModeSelectorModel extends FlutterFlowModel<ModeSelectorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
