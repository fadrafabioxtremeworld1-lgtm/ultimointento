import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'quick_tool_widget.dart' show QuickToolWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class QuickToolModel extends FlutterFlowModel<QuickToolWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
