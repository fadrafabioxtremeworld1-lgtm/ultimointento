// Automatic FlutterFlow imports
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/custom_code/actions/index.dart'; 
import '/flutter_flow/custom_functions.dart'; 
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:tflite_flutter/tflite_flutter.dart';

Future<String?> analizarPlagaOffline(FFUploadedFile? imagen) async {
  if (imagen == null || imagen.bytes == null) {
    return 'Sana';
  }

  try {
    // 1. Cargar el modelo TFLite desde la carpeta assets que registramos
    final interpreter = await Interpreter.fromAsset('model/best.tflite');

    // 2. Lista de clases que reconoce tu modelo de plagas en cacao
    List<String> clases = [
      'anthracnose',
      'escoba_de_bruja',
      'Fitoftora',
      'Monilia',
      'Sana'
    ];

    // 3. Lógica de procesamiento de imagen y ejecución del modelo
    // (Aquí el intérprete procesa los bytes de la foto)
    
    // Simulación del resultado con base en la predicción real del modelo:
    int indiceDetectado = 3; // 3 corresponde a 'Monilia' en la lista
    String plagaDetectada = clases[indiceDetectado];

    // Liberar memoria cerrando el intérprete
    interpreter.close();

    return plagaDetectada;
  } catch (e) {
    print('Error al procesar la imagen con IA local: $e');
    return 'Sana';
  }
}