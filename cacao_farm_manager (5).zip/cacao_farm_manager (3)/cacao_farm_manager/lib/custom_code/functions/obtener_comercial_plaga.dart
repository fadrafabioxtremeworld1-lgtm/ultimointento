import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerComercialPlaga(String? plagaDetectada) {
  String obtenerComercialPlaga(String plagaDetectada) {
    switch (plagaDetectada) {
      case 'Monilia':
        return '1. Uso de fungicidas sistémicos a base de Difenoconazol o Tebuconazol.\n2. Aplicación preventiva con Clorotalonil respetando los periodos de carencia.';
      case 'Fitoftora':
        return '1. Aplicación al suelo o foliar de Fosetil-Aluminio.\n2. Uso de fungicidas a base de Mancozeb alternados con Metalaxil según indicación técnica.';
      case 'anthracnose':
        return '1. Aplicación preventiva de fungicidas protectantes a base de Oxicloruro de Cobre.\n2. Tratamientos curativos con Azoxystrobin en rotación.';
      case 'escoba_de_bruja':
        return '1. Aplicación de oxicloruro de cobre en etapas de brotación y floración nueva.\n2. Uso de agentes de control biológico como Trichoderma harzianum para competir con el hongo en el suelo.';
      default:
        return '1. Ninguno requerido.\n2. Aplicación opcional de abonos foliares ricos en potasio y microelementos de manera preventiva.';
    }
  }
}
