import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerDatosPorPlaga(String? plagaDetectada) {
  String obtenerNombrePlaga(String plagaDetectada) {
    switch (plagaDetectada) {
      case 'Monilia':
        return 'Monilia (Moniliophthora roreri)';
      case 'Fitoftora':
        return 'Fitóftora (Phytophthora)';
      case 'anthracnose':
        return 'Antracnosis (Colletotrichum)';
      case 'escoba_de_bruja':
        return 'Escoba de Bruja (Moniliophthora perniciosa)';
      default:
        return 'Planta Sana';
    }
  }
}
