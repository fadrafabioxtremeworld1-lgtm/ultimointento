import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerEnmiendaPH(double ph) {
  if (ph < 6.0) {
    return 'Cal Agrícola';
  } else if (ph <= 6.8) {
    return 'Compost';
  } else if (ph <= 7.5) {
    return 'Materia Orgánica';
  } else {
    return 'Yeso Agrícola';
  }
}
