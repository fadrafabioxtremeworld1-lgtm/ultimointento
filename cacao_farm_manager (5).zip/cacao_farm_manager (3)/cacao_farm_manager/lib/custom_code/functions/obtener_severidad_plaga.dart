import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerSeveridadPlaga(String? plagaDetectada) {
  String obtenerSeveridadPlaga(String plagaDetectada) {
    switch (plagaDetectada) {
      case 'Monilia':
      case 'escoba_de_bruja':
        return 'Nivel: Urgente';
      case 'Fitoftora':
        return 'Nivel: Moderado';
      case 'anthracnose':
        return 'Nivel: Leve';
      default:
        return 'Nivel: Normal';
    }
  }
}
