import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

List<DateTime>? generarDias() {
// Genera un rango de 30 días para la simulación completa
  DateTime inicio = DateTime.now();
  return List.generate(30, (index) => inicio.add(Duration(days: index)));
}
