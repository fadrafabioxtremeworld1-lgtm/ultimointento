import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String calcularDosisPH(
  double ph,
  String tipoSuelo,
) {
// 1. Muy Ácido (pH < 5.5)
  if (ph < 5.5) {
    if (tipoSuelo == 'Arenoso') return '1.5 ton / Hectárea';
    if (tipoSuelo == 'Arcilloso') return '3.5 ton / Hectárea';
    return '2.5 ton / Hectárea'; // Franco por defecto
  }
  // 2. Ligeramente Ácido (pH 5.5 - 5.9)
  else if (ph < 6.0) {
    if (tipoSuelo == 'Arenoso') return '0.8 ton / Hectárea';
    if (tipoSuelo == 'Arcilloso') return '2.0 ton / Hectárea';
    return '1.2 ton / Hectárea';
  }
  // 3. Óptimo Cacao (pH 6.0 - 6.8)
  else if (ph <= 6.8) {
    if (tipoSuelo == 'Arenoso') return '1.0 ton / Hectárea';
    if (tipoSuelo == 'Arcilloso') return '2.0 ton / Hectárea';
    return '1.5 ton / Hectárea';
  }
  // 4. Neutro / Mod. Alcalino (pH 6.9 - 7.5)
  else if (ph <= 7.5) {
    if (tipoSuelo == 'Arenoso') return '0.8 ton / Hectárea';
    if (tipoSuelo == 'Arcilloso') return '1.8 ton / Hectárea';
    return '1.2 ton / Hectárea';
  }
  // 5. Muy Alcalino (pH > 7.5)
  else {
    if (tipoSuelo == 'Arenoso') return '1.2 ton / Hectárea';
    if (tipoSuelo == 'Arcilloso') return '3.0 ton / Hectárea';
    return '2.0 ton / Hectárea';
  }
}
