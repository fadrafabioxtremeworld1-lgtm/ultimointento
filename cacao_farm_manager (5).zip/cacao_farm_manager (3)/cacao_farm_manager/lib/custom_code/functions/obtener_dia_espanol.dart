import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import '/flutter_flow/custom_functions.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/uploaded_file.dart';
import '/backend/schema/structs/index.dart';

String? obtenerDiaEspanol(DateTime fechs) {
  String obtenerDiaEspanol(DateTime fecha) {
    // Lista con los días de la semana en español
    List<String> dias = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];

    // .weekday devuelve un número del 1 (Lunes) al 7 (Domingo)
    // Ajustamos el índice para que coincida con nuestra lista
    int index = fecha.weekday % 7;

    return dias[index];
  }
}
