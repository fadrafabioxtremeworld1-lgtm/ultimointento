import '/components/activity_item2/activity_item2_widget.dart';
import '/components/button/button_widget.dart';
import '/components/calendar_day/calendar_day_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'lunar_farming_calendar_widget.dart' show LunarFarmingCalendarWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LunarFarmingCalendarModel
    extends FlutterFlowModel<LunarFarmingCalendarWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for CalendarDay.
  late CalendarDayModel calendarDayModel;
  // Model for Button.
  late ButtonModel buttonModel1;
  // Model for Button.
  late ButtonModel buttonModel2;
  // Model for ActivityItem.
  late ActivityItem2Model activityItemModel;

  @override
  void initState(BuildContext context) {
    calendarDayModel = createModel(context, () => CalendarDayModel());
    buttonModel1 = createModel(context, () => ButtonModel());
    buttonModel2 = createModel(context, () => ButtonModel());
    activityItemModel = createModel(context, () => ActivityItem2Model());
  }

  @override
  void dispose() {
    calendarDayModel.dispose();
    buttonModel1.dispose();
    buttonModel2.dispose();
    activityItemModel.dispose();
  }
}
