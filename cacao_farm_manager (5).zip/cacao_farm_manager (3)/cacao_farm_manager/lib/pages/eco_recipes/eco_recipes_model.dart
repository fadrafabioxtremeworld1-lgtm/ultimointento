import '/components/recipe_card/recipe_card_widget.dart';
import '/components/tab_group/tab_group_widget.dart';
import '/components/text_field/text_field_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'eco_recipes_widget.dart' show EcoRecipesWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class EcoRecipesModel extends FlutterFlowModel<EcoRecipesWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for TextField.
  late TextFieldModel textFieldModel;
  // Model for TabGroup.
  late TabGroupModel tabGroupModel;
  // Model for RecipeCard.
  late RecipeCardModel recipeCardModel1;
  // Model for RecipeCard.
  late RecipeCardModel recipeCardModel2;
  // Model for RecipeCard.
  late RecipeCardModel recipeCardModel3;
  // Model for RecipeCard.
  late RecipeCardModel recipeCardModel4;

  @override
  void initState(BuildContext context) {
    textFieldModel = createModel(context, () => TextFieldModel());
    tabGroupModel = createModel(context, () => TabGroupModel());
    recipeCardModel1 = createModel(context, () => RecipeCardModel());
    recipeCardModel2 = createModel(context, () => RecipeCardModel());
    recipeCardModel3 = createModel(context, () => RecipeCardModel());
    recipeCardModel4 = createModel(context, () => RecipeCardModel());
  }

  @override
  void dispose() {
    textFieldModel.dispose();
    tabGroupModel.dispose();
    recipeCardModel1.dispose();
    recipeCardModel2.dispose();
    recipeCardModel3.dispose();
    recipeCardModel4.dispose();
  }
}
