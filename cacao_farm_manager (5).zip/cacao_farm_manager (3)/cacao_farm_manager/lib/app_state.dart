import 'package:flutter/material.dart';
import '/backend/schema/structs/index.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _historialSuelos = prefs
              .getStringList('ff_historialSuelos')
              ?.map((x) {
                try {
                  return EvaluacionSueloStruct.fromSerializableMap(
                      jsonDecode(x));
                } catch (e) {
                  print("Can't decode persisted data type. Error: $e.");
                  return null;
                }
              })
              .withoutNulls
              .toList() ??
          _historialSuelos;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  List<EvaluacionSueloStruct> _historialSuelos = [];
  List<EvaluacionSueloStruct> get historialSuelos => _historialSuelos;
  set historialSuelos(List<EvaluacionSueloStruct> value) {
    _historialSuelos = value;
    prefs.setStringList(
        'ff_historialSuelos', value.map((x) => x.serialize()).toList());
  }

  void addToHistorialSuelos(EvaluacionSueloStruct value) {
    historialSuelos.add(value);
    prefs.setStringList('ff_historialSuelos',
        _historialSuelos.map((x) => x.serialize()).toList());
  }

  void removeFromHistorialSuelos(EvaluacionSueloStruct value) {
    historialSuelos.remove(value);
    prefs.setStringList('ff_historialSuelos',
        _historialSuelos.map((x) => x.serialize()).toList());
  }

  void removeAtIndexFromHistorialSuelos(int index) {
    historialSuelos.removeAt(index);
    prefs.setStringList('ff_historialSuelos',
        _historialSuelos.map((x) => x.serialize()).toList());
  }

  void updateHistorialSuelosAtIndex(
    int index,
    EvaluacionSueloStruct Function(EvaluacionSueloStruct) updateFn,
  ) {
    historialSuelos[index] = updateFn(_historialSuelos[index]);
    prefs.setStringList('ff_historialSuelos',
        _historialSuelos.map((x) => x.serialize()).toList());
  }

  void insertAtIndexInHistorialSuelos(int index, EvaluacionSueloStruct value) {
    historialSuelos.insert(index, value);
    prefs.setStringList('ff_historialSuelos',
        _historialSuelos.map((x) => x.serialize()).toList());
  }

  bool _yaGuardado = false;
  bool get yaGuardado => _yaGuardado;
  set yaGuardado(bool value) {
    _yaGuardado = value;
  }

  List<int> _indicesEjeX = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  List<int> get indicesEjeX => _indicesEjeX;
  set indicesEjeX(List<int> value) {
    _indicesEjeX = value;
  }

  void addToIndicesEjeX(int value) {
    indicesEjeX.add(value);
  }

  void removeFromIndicesEjeX(int value) {
    indicesEjeX.remove(value);
  }

  void removeAtIndexFromIndicesEjeX(int index) {
    indicesEjeX.removeAt(index);
  }

  void updateIndicesEjeXAtIndex(
    int index,
    int Function(int) updateFn,
  ) {
    indicesEjeX[index] = updateFn(_indicesEjeX[index]);
  }

  void insertAtIndexInIndicesEjeX(int index, int value) {
    indicesEjeX.insert(index, value);
  }

  bool _mostrarResultados = false;
  bool get mostrarResultados => _mostrarResultados;
  set mostrarResultados(bool value) {
    _mostrarResultados = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
