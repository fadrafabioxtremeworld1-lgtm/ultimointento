// ignore_for_file: unnecessary_getters_setters

import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EvaluacionSueloStruct extends BaseStruct {
  EvaluacionSueloStruct({
    DateTime? fecha,
    double? ph,
    String? tipoSuelo,
    String? dosis,
    String? enmienda,
  })  : _fecha = fecha,
        _ph = ph,
        _tipoSuelo = tipoSuelo,
        _dosis = dosis,
        _enmienda = enmienda;

  // "fecha" field.
  DateTime? _fecha;
  DateTime? get fecha => _fecha;
  set fecha(DateTime? val) => _fecha = val;

  bool hasFecha() => _fecha != null;

  // "ph" field.
  double? _ph;
  double get ph => _ph ?? 0.0;
  set ph(double? val) => _ph = val;

  void incrementPh(double amount) => ph = ph + amount;

  bool hasPh() => _ph != null;

  // "tipoSuelo" field.
  String? _tipoSuelo;
  String get tipoSuelo => _tipoSuelo ?? '';
  set tipoSuelo(String? val) => _tipoSuelo = val;

  bool hasTipoSuelo() => _tipoSuelo != null;

  // "dosis" field.
  String? _dosis;
  String get dosis => _dosis ?? '';
  set dosis(String? val) => _dosis = val;

  bool hasDosis() => _dosis != null;

  // "enmienda" field.
  String? _enmienda;
  String get enmienda => _enmienda ?? '';
  set enmienda(String? val) => _enmienda = val;

  bool hasEnmienda() => _enmienda != null;

  static EvaluacionSueloStruct fromMap(Map<String, dynamic> data) =>
      EvaluacionSueloStruct(
        fecha: data['fecha'] as DateTime?,
        ph: castToType<double>(data['ph']),
        tipoSuelo: data['tipoSuelo'] as String?,
        dosis: data['dosis'] as String?,
        enmienda: data['enmienda'] as String?,
      );

  static EvaluacionSueloStruct? maybeFromMap(dynamic data) => data is Map
      ? EvaluacionSueloStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'fecha': _fecha,
        'ph': _ph,
        'tipoSuelo': _tipoSuelo,
        'dosis': _dosis,
        'enmienda': _enmienda,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'fecha': serializeParam(
          _fecha,
          ParamType.DateTime,
        ),
        'ph': serializeParam(
          _ph,
          ParamType.double,
        ),
        'tipoSuelo': serializeParam(
          _tipoSuelo,
          ParamType.String,
        ),
        'dosis': serializeParam(
          _dosis,
          ParamType.String,
        ),
        'enmienda': serializeParam(
          _enmienda,
          ParamType.String,
        ),
      }.withoutNulls;

  static EvaluacionSueloStruct fromSerializableMap(Map<String, dynamic> data) =>
      EvaluacionSueloStruct(
        fecha: deserializeParam(
          data['fecha'],
          ParamType.DateTime,
          false,
        ),
        ph: deserializeParam(
          data['ph'],
          ParamType.double,
          false,
        ),
        tipoSuelo: deserializeParam(
          data['tipoSuelo'],
          ParamType.String,
          false,
        ),
        dosis: deserializeParam(
          data['dosis'],
          ParamType.String,
          false,
        ),
        enmienda: deserializeParam(
          data['enmienda'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'EvaluacionSueloStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is EvaluacionSueloStruct &&
        fecha == other.fecha &&
        ph == other.ph &&
        tipoSuelo == other.tipoSuelo &&
        dosis == other.dosis &&
        enmienda == other.enmienda;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([fecha, ph, tipoSuelo, dosis, enmienda]);
}

EvaluacionSueloStruct createEvaluacionSueloStruct({
  DateTime? fecha,
  double? ph,
  String? tipoSuelo,
  String? dosis,
  String? enmienda,
}) =>
    EvaluacionSueloStruct(
      fecha: fecha,
      ph: ph,
      tipoSuelo: tipoSuelo,
      dosis: dosis,
      enmienda: enmienda,
    );
